<?php
require_once("adm/system/funcoes.php");
require_once("adm/system/seguranca.php");
require_once("adm/system/config.php");
require_once("adm/system/classe.ssh.php");

protegePagina("admin");
if( $_SESSION['tipo'] == "user"){
	expulsaVisitante();			
}
		$data_atual = date("Y-m-d");
		$SQLAdministrador = "SELECT * FROM admin WHERE id_administrador = '".$_SESSION['usuarioID']."'";
        $SQLAdministrador = $conn->prepare($SQLAdministrador);
        $SQLAdministrador->execute();
        $administrador = $SQLAdministrador->fetch();
?>
<!DOCTYPE html>
<html>
<head>
	<!-- PRESERVE O ORIGINAL FOI FEITO COM CARINHO PENSANDO EM VOCE
		 TELEGRAM: t.me/digitandoo
		 DATA: 26/10/2017
		 =================================================================
		         +++++++++++++++++ ATENÇÃO +++++++++++++++++++++ 
		 NAO MECHA NA ONDE NAO SABE ESSE PAINE NAO TEM ASSISTENCIA
		 ELE FOI ENTREGUE A VOCE FUNCIONANDO PERFEITO ENTAO SE FOR ALTERAR
		 É BOM SABER AONDE TA MEXENDO 
		 ================================================================== 
	!-->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="Web Page Builder Description">
  <title>Home | Upload De Arquivos</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
</head>
<body>
<section class="menu cid-qzbHlxYkm4" once="menu" id="menu2-q" data-rv-view="164">
	<nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-toggleable-sm bg-color transparent">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                
                <span class="navbar-caption-wrap"><a class="navbar-caption text-info display-5" href="home.php">ADM.PRO ULTIMATE</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
			<div class="navbar-buttons mbr-section-btn">
			<a class="btn btn-sm btn-primary display-4" href="help.php">
			<span class="mbri-italic mbr-iconfont mbr-iconfont-btn"></span>SUPORTE<br></a>
			<a class="btn btn-sm btn-primary display-4" href="sair.php">
			<span class="mbri-login mbr-iconfont mbr-iconfont-btn"></span>SAIR</a></div>
        </div>
    </nav>
</section>
<section class="cid-qz6md37QjE" id="header15-l" data-rv-view="63">
	<div class="container align-right">
		<div class="row">
    <div class="mbr-white col-lg-8 col-md-7 content-container">
		<p class="mbr-text pb-3 mbr-fonts-style display-5">Importe o arquivo da operadora VIVO
		<br>Coloque nome padrão no arquivo
		<br>( vivo.ehi ) sem parenteses</p>
    </div>
    <div class="col-lg-4 col-md-5">
    <div class="form-container">
        <div class="media-container-column" data-form-type="formoid">
			<form class="mbr-form" action="recebe_upload.php" method="post" enctype="multipart/form-data">
                <div data-for="arquivo">
                    <div class="form-group">
                        <input type="file" class="form-control px-3" name="arquivo" data-form-field="arquivo" placeholder="Nenhum Arquivo" required="" id="name-header15-l">
                    </div>
                </div>
                <span class="input-group-btn">
				<button href="" type="submit" class="btn btn-form btn-info display-4">
				<span class="mbri-rocket mbr-iconfont mbr-iconfont-btn">
				</span>Enviar</button></span>
            </form>
        </div>
    </div>
    </div>
</div>
    </div>
    </section>
<section class="cid-qz6mdDntwW" id="header15-m" data-rv-view="66">
    <div class="container align-right">
	<div class="row">
    <div class="mbr-white col-lg-8 col-md-7 content-container">
	<p class="mbr-text pb-3 mbr-fonts-style display-5">Importe o arquivo da operadora CLARO
	<br>Coloque nome padrão no arquivo
	<br>( claro.ehi )&nbsp;sem parenteses</p>
    </div>
    <div class="col-lg-4 col-md-5">
    <div class="form-container">
        <div class="media-container-column" data-form-type="formoid">
			<form class="mbr-form" action="recebe_upload.php" method="post" enctype="multipart/form-data">
                <div data-for="name">
                    <div class="form-group">
                        <input type="file" class="form-control px-3" name="arquivo" data-form-field="Name" placeholder="Nenhum Arquivo" required="" id="name-header15-m">
                    </div>
                </div>
				<span class="input-group-btn">
				<button href="" type="submit" class="btn btn-form btn-primary display-4">
				<span class="mbri-rocket mbr-iconfont mbr-iconfont-btn">
				</span>Enviar</button></span>
            </form>
        </div>
    </div>
    </div>
</div>
    </div>
    </section>
<section class="cid-qz6njNXIIQ" id="header15-n" data-rv-view="69">
    <div class="container align-right">
	<div class="row">
    <div class="mbr-white col-lg-8 col-md-7 content-container">
      <p class="mbr-text pb-3 mbr-fonts-style display-5">Importe o arquivo da operadora OI
	  <br>Coloque nome padrão no arquivo
	  <br>( oi.ehi ) sem parenteses</p>
    </div>
    <div class="col-lg-4 col-md-5">
    <div class="form-container">
        <div class="media-container-column" data-form-type="formoid">
			<form class="mbr-form" action="recebe_upload.php" method="post" enctype="multipart/form-data">
                <div data-for="name">
                    <div class="form-group">
                        <input type="file" class="form-control px-3" name="arquivo" data-form-field="Name" placeholder="Nenhum Arquivo" required="" id="name-header15-n">
                    </div>
                </div>
                <span class="input-group-btn">
				<button href="" type="submit" class="btn btn-form btn-success display-4">
				<span class="mbri-rocket mbr-iconfont mbr-iconfont-btn">
				</span>Enviar</button></span>
            </form>
        </div>
    </div>
    </div>
</div>
    </div>
</section>
	<script src="assets/web/assets/jquery/jquery.min.js"></script>
	<script src="assets/popper/popper.min.js"></script>
	<script src="assets/tether/tether.min.js"></script>
	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/smooth-scroll/smooth-scroll.js"></script>
	<script src="assets/theme/js/script.js"></script>
<div id="scrollToTop" class="scrollToTop mbr-arrow-up">
 <a style="text-align: center;">
 <i class="mbri-down mbr-iconfont"></i></a>
 </div>
  <script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>